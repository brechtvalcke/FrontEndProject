export class ActivityVoteEvent {
    public groupId: String;
    public activityId: String;
    public userId: String;
}
