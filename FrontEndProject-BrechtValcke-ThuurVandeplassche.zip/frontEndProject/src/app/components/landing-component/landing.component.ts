
import {Component} from '@angular/core';

@Component({
    selector: 'index-component',
    templateUrl: 'landing.component.html',
    styleUrls: ['landing.component.scss']
})

export class LandingComponent {

}
