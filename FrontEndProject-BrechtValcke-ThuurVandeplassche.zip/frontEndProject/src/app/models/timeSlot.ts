
export class TimeSlot {
    public _id: String;
    public time: Date;
    public votes: [String];
}
