import { SocketService } from './../../services/socket.service';
import {Component, OnInit} from '@angular/core';

@Component({
    selector: 'main-component',
    templateUrl: 'main.component.html',
    styleUrls: ['main.component.scss']
})

export class MainComponent implements OnInit {
    constructor(private socketService: SocketService) {}
    ngOnInit() {
        this.socketService.connect();
    }
}
