export class TimeslotVoteEvent {
    public groupId: String;
    public timeslotId: String;
    public userId: String;
}
