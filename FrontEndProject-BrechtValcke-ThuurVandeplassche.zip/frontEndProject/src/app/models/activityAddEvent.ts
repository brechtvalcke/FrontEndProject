import { Activity } from './activity';
export class ActivityAddEvent {
    public groupId: String;
    public activity: Activity;
}
