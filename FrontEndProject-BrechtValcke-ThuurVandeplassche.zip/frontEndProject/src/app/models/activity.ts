export class Activity {
    public _id: String;
    public name: String;
    public votes: [String];
    public selected: Boolean = false;
}
