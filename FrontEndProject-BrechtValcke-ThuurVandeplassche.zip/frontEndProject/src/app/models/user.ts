export class User {
    public _id: String;
    public name: String;
    public photoUrl: String;
    public setId(id: String) {
        this._id = id;
    }
}
