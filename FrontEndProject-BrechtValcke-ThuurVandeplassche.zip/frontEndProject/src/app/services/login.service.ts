export class LoginService {
    isLoggedIn(): boolean {
        const token = null;
        // return !(token === undefined || token === null || token === '' );
        return true;
    }
}
