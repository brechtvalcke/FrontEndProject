export class UserTyping {
    public groupId: String;
    public userId: String;
}
