import { TimeSlot } from './timeSlot';
export class TimeslotAddEvent {
    public groupId: String;
    public timeslot: TimeSlot;
}
